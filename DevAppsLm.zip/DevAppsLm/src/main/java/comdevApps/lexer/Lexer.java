package comdevApps.lexer;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StreamTokenizer;
import java.io.*;
import com.devApps.utils.DoubleHashMap;

public class Lexer {
	private StreamTokenizer input;
	private int symbol = NONE;
	public static final int INVALID = -1;
	public static final int NONE = 0;
	public static final int PLUS = 1;
	public static final int MINUS = 2;
	public static final int CONSTANT = 5;
	public static final int MULTIPLY = 3;
	public static final int DIVIDE = 4;
	public static final int LEFT = 7;
	public static final int RIGHT = 8;
	public static final int EOF = 9;
	public static final int EOL = 12;
	
	public final DoubleHashMap<String, Integer> mnemonics = new DoubleHashMap<String, Integer>() {{
		put("+", PLUS);
		put("-", MINUS);
		put("*", MULTIPLY);
		put("/", DIVIDE);
		put("(", LEFT);
		put(")", RIGHT);
	}};
	
	public static final String CONST= "[0-9]*\\.?[0-9]*";
	
	public String getString() {
		return input.sval;
	}
	
	public Lexer(InputStream in) {
		Reader r = new BufferedReader(new InputStreamReader(in));
		input = new StreamTokenizer(r);

		input.resetSyntax();
		input.eolIsSignificant(true);
		input.wordChars('0', '9');
		input.whitespaceChars('\u0000', ' '); //characters from 0 to 32
		input.whitespaceChars('\n', '\t');
	}
	
	public int nextSymbol() {
		try {
			switch (input.nextToken()) {
				case StreamTokenizer.TT_EOL:
					symbol = EOL; break;
				case StreamTokenizer.TT_EOF:
					symbol = EOF; break;
				case StreamTokenizer.TT_WORD: {
					if(input.sval.matches(CONST)) symbol = CONSTANT;
					else symbol = INVALID;
					break;
				}
				default:
					symbol = (mnemonics.get(Character.toString((char)input.ttype)) != null) ? mnemonics.get(Character.toString((char)input.ttype)) : NONE; break;
			}
		}catch (IOException e) {
			
		}
		return symbol;
	}
	public String stringfy(int token) {
		switch (token) {
			case CONSTANT: return getString();
			default: return mnemonics.getValue(token);
		}
	}
	
	public static void main(String[] args) {
		Lexer l = new Lexer(new ByteArrayInputStream("2+3.2*3-3".getBytes()));
		int s;
		while ( (s = l.nextSymbol()) != Lexer.EOF) if(s != EOL) System.out.println(s + " " + l.stringfy(s));
	}
}
