package com.devApps.utils;

import java.io.InputStream;


import comdevApps.lexer.Lexer;

public class util {
	public static boolean isNumber(String str) {
        return str.matches(Lexer.CONST);
    }
	
	
}
