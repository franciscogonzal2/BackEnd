package com.devApps;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevAppsLmApplication {

	public static void main(String[] args) {
		SpringApplication.run(DevAppsLmApplication.class, args);
	}

}
