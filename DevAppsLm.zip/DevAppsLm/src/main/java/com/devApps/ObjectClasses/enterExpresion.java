package com.devApps.ObjectClasses;

import java.util.HashMap;
import java.util.LinkedList;
import com.devApps.utils.*;
import comdevApps.lexer.Lexer;

public class enterExpresion {
	private LinkedList<String> stack = new LinkedList<String>();
    private String bytecode;
    
    public enterExpresion(String expression) {
        this.bytecode = expression;
    }
    
    public static boolean isNumber(String str) {
        return str.matches(Lexer.CONST);
    }
    
public HashMap<String, Double> context = new HashMap<String, Double>();
	
    public Double evaluate() {
	    System.out.println(bytecode);
	    String code[] = bytecode.split(" ");
        String instruction;
	    double firstOperand, secondOperand;
	    int instructionPointer = 0; 
	    while (instructionPointer < code.length && instructionPointer > -1) {
            instruction = code[instructionPointer++];
		    if(isNumber(instruction)) {
                stack.push(instruction);
            } else {
			   if (instruction.equals("/")) {
				    secondOperand = cast(stack.pop());
				    firstOperand = cast(stack.pop());
				    stack.push("" + (firstOperand / secondOperand));
			    } else if (instruction.equals("*")) {
				    secondOperand = cast(stack.pop());
				    firstOperand = cast(stack.pop());
				    stack.push("" + (firstOperand * secondOperand));
			    } else if (instruction.equals("+")) {
				    secondOperand = cast(stack.pop());
				    firstOperand = cast(stack.pop());
				    stack.push("" + (firstOperand + secondOperand));
			    } else if (instruction.equals("-")) {
				    secondOperand = cast(stack.pop());
				    if(stack.peek() != null && isNumber(stack.peek())) { // unary minus
				    	firstOperand = cast(stack.pop());
				    	stack.push("" + (firstOperand - secondOperand));
				    } else {
				    	stack.push("" + (-secondOperand));
				    }
			    } else {
		            throw new RuntimeException("no se ha podido realizar la sustitucion" + instruction);
	            }
            }
        }
        return cast(stack.pop());
    }

	private Double cast(String token) {
		return Double.parseDouble(token);
	}

	public double ackermann(double m, double n) {
		if (m < 0 || n < 0) {
			throw new IllegalArgumentException("No numeros negativos");
		}
		if (m == 0) {
			return n + 1;
		} else if (n == 0) {
			return ackermann(m-1, 1); // Corrected!
		} else {
			return ackermann(m-1, ackermann(m,n-1));
		}
	}
}
