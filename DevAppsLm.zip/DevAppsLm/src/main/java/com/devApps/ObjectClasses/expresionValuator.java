package com.devApps.ObjectClasses;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Stack;

import comdevApps.lexer.Lexer;

public class expresionValuator {
	 private StringBuilder output;
	    private Stack<String> stack;
	    private String expression;
		private Lexer lexer;
	    private HashMap<String, int[]> proprierties = new HashMap<String, int[]>(5);
		private HashSet<String> functions = new HashSet<String>();
}
