package com.devApps.ObjectClasses;

public class Expresion {
private String mathExpresion;

	
	public Expresion(String mathExpresion) {
		super();
		this.mathExpresion = mathExpresion;
	}

	public String getMathExpresion() {
		return mathExpresion;
	}


	public void setMathExpresion(String mathExpresion) {
		this.mathExpresion = mathExpresion;
	}
}
